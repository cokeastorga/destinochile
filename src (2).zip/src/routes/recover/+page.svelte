<script lang="ts">
  import { auth } from '$lib/firebase';
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { sendEmailVerification, onAuthStateChanged } from 'firebase/auth';

  let userEmail: string = '';
  let verificationSent = false;
  let resendDisabled = false;
  let error: string | null = null;

  onMount(() => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        userEmail = user.email ?? '';
        if (user.emailVerified) {
          goto('/dashboard');
        }
      } else {
        goto('/login');
      }
    });
  });

  async function resendVerification() {
    error = null;
    verificationSent = false;

    const user = auth.currentUser;
    if (!user || resendDisabled || user.emailVerified) return;

    try {
      await sendEmailVerification(user);
      verificationSent = true;
      resendDisabled = true;

      // Habilita el botón después de 60 segundos
      setTimeout(() => {
        resendDisabled = false;
      }, 60000);
    } catch (err: any) {
      if (err.code === 'auth/too-many-requests') {
        error = 'Has solicitado demasiados correos. Intenta nuevamente más tarde.';
      } else {
        error = err.message || 'No se pudo enviar el correo.';
      }
    }
  }
</script>

<svelte:head>
  <title>Verificación de correo</title>
</svelte:head>

<div class="flex flex-col items-center justify-center min-h-screen bg-gray-100">
  <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
    <h1 class="text-2xl font-bold mb-4 text-center">Verifica tu correo</h1>

    <p class="text-sm text-center mb-4 text-gray-600">
      Se ha enviado un correo a <strong>{userEmail}</strong>. Por favor verifica tu dirección de correo para continuar.
    </p>

    {#if error}
      <div class="bg-red-100 text-red-700 p-2 mb-4 rounded text-sm">{error}</div>
    {/if}

    {#if verificationSent}
      <div class="bg-green-100 text-green-700 p-2 mb-4 rounded text-sm">
        Correo enviado correctamente. Revisa tu bandeja de entrada.
      </div>
    {/if}

    <button
      class="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded disabled:opacity-50"
      on:click={resendVerification}
      disabled={resendDisabled}
    >
      {resendDisabled ? 'Espera 60 segundos...' : 'Reenviar correo de verificación'}
    </button>

    <div class="text-center text-sm mt-4">
      <a href="/login" class="text-blue-500 hover:underline">Volver al login</a>
    </div>
  </div>
</div>

<style>
  :global(body) {
    @apply bg-gray-100;
  }
</style>
