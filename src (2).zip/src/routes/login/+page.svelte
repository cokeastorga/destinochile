<script lang="ts">
  import { signInWithEmailAndPassword } from 'firebase/auth';
  import { auth } from '$lib/firebase';
  import { goto } from '$app/navigation';
  import { onMount } from 'svelte';

  let email = '';
  let password = '';
  let showPassword = false;
  let error: string | null = null;
  let loading = false;

  const handleLogin = async () => {
    error = null;
    loading = true;
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      if (!user.emailVerified) {
        error = 'Debes verificar tu correo antes de continuar.';
        loading = false;
        return;
      }
      goto('/dashboard');
    } catch (err: any) {
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        error = 'Correo o contraseña incorrectos.';
      } else {
        error = err.message;
      }
      loading = false;
    }
  };
</script>

<div class="flex flex-col min-h-screen items-center justify-center bg-gray-100">
  <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full max-w-md">
    <h1 class="text-2xl font-bold mb-4 text-center">Iniciar sesión</h1>

    {#if error}
      <div class="bg-red-100 text-red-700 p-2 mb-4 rounded text-sm">{error}</div>
    {/if}

    <form on:submit|preventDefault={handleLogin} class="space-y-4">
      <input
        type="email"
        bind:value={email}
        placeholder="Correo electrónico"
        class="w-full px-4 py-2 border rounded"
        required
      />

      <div class="relative">
        <input
          type={showPassword ? 'text' : 'password'}
          bind:value={password}
          placeholder="Contraseña"
          class="w-full px-4 py-2 border rounded pr-10"
          required
        />
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          stroke-width="1.5"
          stroke="currentColor"
          class="w-5 h-5 absolute right-3 top-2.5 text-gray-400 hover:text-gray-700 cursor-pointer transition"
          on:click={() => (showPassword = !showPassword)}
        >
          {#if showPassword}
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19.5c-5.523 0-10-4.477-10-10a9.956 9.956 0 013.132-7.184m16.668 16.668L3 3" />
          {:else}
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-.274.854-.68 1.651-1.192 2.368" />
          {/if}
        </svg>
      </div>

      <button
        type="submit"
        class="w-full bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 disabled:opacity-50"
        disabled={loading}
      >
        {loading ? 'Ingresando...' : 'Ingresar'}
      </button>
    </form>

    <div class="mt-4 text-sm text-center">
      ¿No tienes cuenta?
      <a href="/register" class="text-blue-500 hover:underline ml-1">Regístrate</a>
    </div>
    <div class="mt-2 text-sm text-center">
      ¿Olvidaste tu contraseña?
      <a href="/recover" class="text-blue-500 hover:underline ml-1">Recupérala</a>
    </div>
  </div>
</div>

<style>
  :global(body) {
    @apply bg-gray-100;
  }
</style>
