<script lang="ts">
  import { onMount } from 'svelte';
  import { db } from '$lib/firebase';
  import { collection, getDocs, doc, getDoc } from 'firebase/firestore';

  let clientes: any[] = [];
  let clienteSeleccionado = '';
  let ejecutivo = '';
  let email = '';
  let referenciaPasajero = '';

  let destino = '';
  let fechaInicio = '';
  let fechaFin = '';
  let tipoCliente = 'Extranjero';
  let tipoServicio = '';
  let servicio = '';

  let markups: any[] = [];
let tipoCambioReceptivo = 950; // Puedes ajustar el valor predeterminado
let tipoCambioContable = 960;  // Puedes ajustar el valor predeterminado


  let configuraciones: any[] = [];
  let tiposDeServicio: string[] = [];
  let serviciosPorTipo: { [tipo: string]: string[] } = {};

  let resultados: any[] = [];
  let serviciosSeleccionados: any[] = [];

  onMount(async () => {
    
    // Fetch clients
    const snapshotClientes = await getDocs(collection(db, 'clientes'));
    clientes = snapshotClientes.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

    // Obtener referencia al documento 'global' dentro de la colección 'configuracion'
    const docRef = doc(db, 'configuracion', 'global');
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
  const data = docSnap.data();
  configuraciones = data?.tiposServicio || [];
  markups = data?.tiposServicio || [];
  tipoCambioReceptivo = data?.cambioReceptivo || 950;
  tipoCambioContable = data?.cambioContable || 960;

      // Extract tiposDeServicio and serviciosPorTipo
      tiposDeServicio = [...new Set(configuraciones.map((c) => c.categoria))].filter(Boolean);
      serviciosPorTipo = configuraciones.reduce((acc, c) => {
        if (!c.categoria || !c.servicio) return acc;
        if (!acc[c.categoria]) acc[c.categoria] = [];
        if (!acc[c.categoria].includes(c.servicio)) acc[c.categoria].push(c.servicio);
        return acc;
      }, {});
    } else {
      console.warn('No se encontró el documento "global" en la colección "configuracion".');
    }
  });

  function seleccionarCliente(id: string) {
    const cliente = clientes.find((c) => c.id === id);
    if (cliente) {
      clienteSeleccionado = id;
      email = cliente.correo1 || '';
      ejecutivo = cliente.ejecutivo || '';
      referenciaPasajero = cliente.referencia_pasajero || '';
    }

  }

  
  async function buscarServicios() {
  resultados = [];

  if (!destino || !tipoServicio || !servicio) return;

  const snapshotProveedores = await getDocs(collection(db, 'proveedores'));

  for (const proveedorDoc of snapshotProveedores.docs) {
    const serviciosRef = collection(db, `proveedores/${proveedorDoc.id}/servicios`);
    const serviciosSnap = await getDocs(serviciosRef);

    for (const docu of serviciosSnap.docs) {
      const data = docu.data();

      const ciudadServicio = (data.CIUDAD || '').toUpperCase();
      const destinoNormalizado = destino.toUpperCase();
      const tipoServicioUpper = (data["TIPO DE SERVICIO"] || '').toUpperCase();
      const servicioUpper = (data.SERVICIO || '').toUpperCase();

      console.log('Evaluando servicio:', data["NOMBRE PRODUCTO SERVICIO"]);
      console.log('  Ciudad Servicio:', ciudadServicio, 'vs Destino:', destinoNormalizado);
      console.log('  Tipo Servicio:', tipoServicioUpper, 'vs Buscado:', tipoServicio.toUpperCase());
      console.log('  Servicio Nombre:', servicioUpper, 'vs Buscado:', servicio.toUpperCase());

      const inicioServicio = data.FECHA_INICIO?.split('T')[0];
      const finServicio = data.FECHA_FIN?.split('T')[0];
      const inicioBusqueda = fechaInicio ? fechaInicio : null;
      const finBusqueda = fechaFin ? fechaFin : null;

      const cumpleFiltros =
  ciudadServicio === destinoNormalizado &&
  (data["TIPO DE SERVICIO"] || '').toUpperCase() === tipoServicio.toUpperCase() &&
  (data["SERVICIO/PRODUCTO/ F.I.T"] || '').toUpperCase() === servicio.toUpperCase() && // <-- CAMBIO AQUÍ
  (!inicioBusqueda && !finBusqueda ||
   (!inicioBusqueda || inicioBusqueda <= finServicio) &&
   (!finBusqueda || finBusqueda >= inicioServicio));

      if (cumpleFiltros) {
        console.log('  ¡Coincidencia encontrada!');
        const markup = markups.find(
          (m) => m.categoria === tipoServicio && m.servicio === servicio
        )?.markup;

        let tarifaFinal = data["TARIFA NETA"];
        let moneda = data.MONEDA;

        if (markup) {
          let neta = data["TARIFA NETA"];
          let porcentaje = 1 - markup / 100;
          let netaConvertida = neta;

          if (tipoCliente === 'Extranjero' && moneda === 'PESO') {
            netaConvertida = neta / tipoCambioReceptivo;
            moneda = 'USD';
          } else if (tipoCliente === 'Nacional' && moneda === 'DÓLAR') {
            netaConvertida = neta * tipoCambioContable;
            moneda = 'PESO';
          }

          tarifaFinal = Math.round(netaConvertida / porcentaje);

          if (tipoCliente === 'Nacional' && moneda === 'PESO') {
            tarifaFinal = Math.round(tarifaFinal * 1.19); // aplicar IVA
          }
        }

        resultados.push({
          proveedor: data.PROVEEDOR,
          nombre: data["NOMBRE PRODUCTO SERVICIO"],
          descripcion: data.DESCRIPCIÓN,
          moneda,
          tarifa_neta: data["TARIFA NETA"],
          tarifa_final: tarifaFinal
        });
      }
    }
  }
  console.log('Resultados de la búsqueda:', resultados);
}




  

  function agregarServicio(servicio: any) {
    serviciosSeleccionados.push({ ...servicio });
  }
</script>

<div class="p-6 max-w-7xl mx-auto">
  <h1 class="text-2xl font-bold mb-6">Cotización</h1>

  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 text-sm">
    <select bind:value={clienteSeleccionado} on:change={(e) => seleccionarCliente(e.target.value)} class="border px-2 py-1 rounded w-full">
      <option value="">Seleccione cliente</option>
      {#each clientes as c}
        <option value={c.id}>{c.nombre}</option>
      {/each}
    </select>
    <input type="text" placeholder="Ejecutivo" bind:value={ejecutivo} class="border px-2 py-1 rounded w-full" disabled />
    <input type="email" placeholder="Correo electrónico" bind:value={email} class="border px-2 py-1 rounded w-full" disabled />
    <input type="text" placeholder="Referencia pasajero" bind:value={referenciaPasajero} class="border px-2 py-1 rounded w-full" />
  </div>

  <hr class="my-4" />

  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 mb-4 text-sm">
    <input type="text" placeholder="Destino" bind:value={destino} class="border px-2 py-1 rounded w-full" />
    <input type="date" bind:value={fechaInicio} class="border px-2 py-1 rounded w-full" />
    <input type="date" bind:value={fechaFin} class="border px-2 py-1 rounded w-full" />
    <select bind:value={tipoCliente} class="border px-2 py-1 rounded w-full">
      <option>Extranjero</option>
      <option>Nacional</option>
    </select>
    <select bind:value={tipoServicio} class="border px-2 py-1 rounded w-full">
      <option value="">Tipo de Servicio</option>
      {#each tiposDeServicio as tipo}
        <option value={tipo}>{tipo}</option>
      {/each}
    </select>
    <select bind:value={servicio} class="border px-2 py-1 rounded w-full">
      <option value="">Servicio</option>
      {#if serviciosPorTipo[tipoServicio]}
        {#each serviciosPorTipo[tipoServicio] as s}
          <option value={s}>{s}</option>
        {/each}
      {/if}
    </select>
  </div>

  <div class="text-center mb-8">
    <button on:click={buscarServicios} class="bg-blue-500 hover:bg-blue-600 text-white px-8 py-2 rounded text-lg">Buscar</button>
  </div>

  <div class="mt-8">
    <h2 class="text-lg font-semibold mb-2">Resultados de la Búsqueda</h2>
    <table class="w-full border text-sm">
      <thead class="bg-gray-100">
        <tr>
          <th class="px-4 py-2">Proveedor</th>
          <th class="px-4 py-2">Servicio</th>
          <th class="px-4 py-2">Descripción</th>
          <th class="px-4 py-2">Moneda</th>
          <th class="px-4 py-2">Tarifa</th>
          <th class="px-4 py-2"></th>
        </tr>
      </thead>
      <tbody>
        {#each resultados as s}
          <tr class="border-t">
            <td class="px-4 py-2">{s.proveedor}</td>
            <td class="px-4 py-2">{s.nombre}</td>
            <td class="px-4 py-2">{s.descripcion}</td>
            <td class="px-4 py-2">{s.moneda}</td>
            <td class="px-4 py-2">{s.tarifa_neta}</td>
            <td class="px-4 py-2">
              <button class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-xs" on:click={() => agregarServicio(s)}>
                Agregar
              </button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>

  <div class="mt-10">
    <h2 class="text-lg font-semibold mb-2">Servicios Seleccionados</h2>
    <ul class="list-disc ml-6">
      {#each serviciosSeleccionados as s}
        <li>{s.nombre} ({s.tarifa_neta} {s.moneda})</li>
      {/each}
    </ul>
  </div>
</div>

<style>
  :global(body) {
    @apply bg-gray-100;
  }
</style>