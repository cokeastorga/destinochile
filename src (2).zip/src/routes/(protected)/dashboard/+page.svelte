<script lang="ts">
  import { auth } from '$lib/firebase';
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { onAuthStateChanged, signOut } from 'firebase/auth';
  import Sidebar from '$lib/components/Sidebar.svelte';

  let userEmail: string | null = null;

  onMount(() => {
    onAuthStateChanged(auth, (user) => {
      if (user && user.emailVerified) {
        userEmail = user.email;
      } else if (user && !user.emailVerified) {
        goto('/verify-email');
      } else {
        goto('/login');
      }
    });
  });

  function logout() {
    signOut(auth).then(() => {
      goto('/login');
    });
  }
</script>

<svelte:head>
  <title>Dashboard</title>
</svelte:head>



