<script lang="ts">
  import { goto } from '$app/navigation';
  import { signOut } from 'firebase/auth';
  import { auth } from '$lib/firebase';

  import {
    LayoutDashboard,
    FileText,
    Users,
    Briefcase,
    CalendarCheck,
    LogOut,
    ShieldCheck,
    Settings
  } from 'lucide-svelte';

  function logout() {
    signOut(auth).then(() => goto('/login'));
  }

  const menuItems = [
    { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { label: 'Cotizaciones', href: '/cotizaciones', icon: FileText },
    { label: 'Reservas', href: '/reservas', icon: CalendarCheck },
    { label: 'Clientes', href: '/clientes', icon: Users },
    { label: 'Proveedores', href: '/proveedores', icon: Briefcase },
    { label: 'Ventas', href: '/ventas', icon: FileText },
    { label: 'Usuarios y Roles', href: '/usuarios', icon: ShieldCheck },
    { label: 'Configuración', href: '/configuracion', icon: Settings }
  ];
</script>

<div class="flex min-h-screen">
  <!-- Sidebar -->
  <aside class="w-64 bg-blue-600 text-white flex flex-col p-4 space-y-4">
    <div class="text-xl font-bold mb-6 text-center">Destino Chile</div>

    {#each menuItems as { label, href, icon }}
      <a
        href={href}
        class="flex items-center gap-2 px-2 py-2 rounded hover:bg-blue-700 transition text-sm"
      >
        <svelte:component this={icon} class="w-4 h-4" />
        {label}
      </a>
    {/each}

    <button
      on:click={logout}
      class="mt-auto flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white py-2 px-2 rounded text-sm"
    >
      <LogOut class="w-4 h-4" />
      Cerrar sesión
    </button>
  </aside>

  <!-- Main content -->
  <main class="flex-1 p-6 bg-gray-50">
    <slot />
  </main>
</div>