<script lang="ts">
  let email = '';
  let password = '';
  let error = '';

  const handleLogin = async () => {
    error = '';
    try {
      console.log('Iniciar sesión con', email, password);
      // Aquí luego conectamos Firebase
    } catch (err) {
      error = 'Error al iniciar sesión';
    }
  };
</script>

<div class="flex items-center justify-center min-h-screen bg-gray-50">
  <div class="bg-white p-8 rounded shadow w-full max-w-md">
    <h1 class="text-2xl font-bold mb-6 text-center">Iniciar Sesión</h1>
    <input
      type="email"
      bind:value={email}
      placeholder="Correo"
      class="w-full px-4 py-2 mb-4 border rounded"
    />
    <input
      type="password"
      bind:value={password}
      placeholder="Contraseña"
      class="w-full px-4 py-2 mb-4 border rounded"
    />
    <button
      on:click={handleLogin}
      class="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition"
    >
      Entrar
    </button>
    {#if error}
      <p class="text-red-500 mt-4 text-center">{error}</p>
    {/if}
  </div>
</div>
