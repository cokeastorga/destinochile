<script lang="ts">
  import { auth } from '$lib/firebase';
  import { sendPasswordResetEmail } from 'firebase/auth';
  import { goto } from '$app/navigation';

  let email = '';
  let success = '';
  let error = '';

  async function recover() {
    try {
      await sendPasswordResetEmail(auth, email);
      success = 'Te hemos enviado un enlace para restablecer tu contraseña.';
      error = '';
    } catch (err) {
      success = '';
      error = (err as Error).message;
    }
  }
</script>

<div class="max-w-md mx-auto mt-20 p-6 border rounded bg-white shadow">
  <h1 class="text-2xl font-bold mb-4 text-center">Recuperar Contraseña</h1>
  <form on:submit|preventDefault={recover} class="space-y-4">
    <input type="email" bind:value={email} placeholder="Correo registrado" class="w-full px-4 py-2 border rounded" required />
    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Enviar correo</button>
  </form>

  {#if success}
    <p class="mt-4 text-green-600 text-sm">{success}</p>
  {:else if error}
    <p class="mt-4 text-red-500 text-sm">{error}</p>
  {/if}

  <p class="mt-4 text-center text-sm">
    ¿Ya tienes una cuenta? <a href="/login" class="text-blue-600 hover:underline">Inicia sesión</a>
  </p>
</div>
