<script lang="ts">
  import { auth } from '$lib/firebase';
  import { createUserWithEmailAndPassword } from 'firebase/auth';
  import { goto } from '$app/navigation';

  let email = '';
  let password = '';
  let error = '';

  async function register() {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      goto('/login');
    } catch (err) {
      error = (err as Error).message;
    }
  }
</script>

<div class="max-w-md mx-auto mt-20 p-6 border rounded bg-white shadow">
  <h1 class="text-2xl font-bold mb-4 text-center">Crear Cuenta</h1>
  <form on:submit|preventDefault={register} class="space-y-4">
    <input type="email" bind:value={email} placeholder="Correo electrónico" class="w-full px-4 py-2 border rounded" required />
    <input type="password" bind:value={password} placeholder="Contraseña" class="w-full px-4 py-2 border rounded" required />
    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Registrarse</button>
  </form>
  {#if error}
    <p class="mt-4 text-red-500 text-sm">{error}</p>
  {/if}
  <p class="mt-4 text-center text-sm">
    ¿Ya tienes una cuenta? <a href="/login" class="text-blue-600 hover:underline">Inicia sesión</a>
  </p>
</div>
