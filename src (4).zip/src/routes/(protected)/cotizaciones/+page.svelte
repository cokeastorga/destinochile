<script lang="ts">
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase';
	import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
	import ClientSelector from '$lib/components/ClientSelector.svelte';
	import ClientDetails from '$lib/components/ClientDetails.svelte';
	import SearchFilters from '$lib/components/SearchFilters.svelte';
	import ServiceResults from '$lib/components/ServiceResults.svelte';
	import SelectedServices from '$lib/components/SelectedServices.svelte';
	import LoadingSpinner from '$lib/components/LoadingSpinner.svelte';

	let clientes: any[] = [];
	let clienteSeleccionado = '';
	let ejecutivo = '';
	let email = '';
	let referenciaPasajero = '';
	let cantidadPasajeros = 1;

	let tipoCliente = 'Extranjero';
	let tipoCambioReceptivo = 950;
	let tipoCambioContable = 960;
	let markups: any[] = [];

	let configuraciones: any[] = [];
	let tiposDeServicio: string[] = [];
	let serviciosPorTipo: { [tipo: string]: string[] } = {};

	let resultados: any[] = [];
	let serviciosSeleccionados: any[] = [];
	let cargando = false;

	// Estados para los filtros
	let destino = '';
	let fechaInicio = '';
	let fechaFin = '';
	let tipoServicio = '';
	let servicio = '';
	let categoriaHotel = '';
	let tourPrivado = '';
	let duracionTour = '';
	let filtroPrecioMin = 0;
	let filtroPrecioMax = 1000000;

	onMount(async () => {
		// Fetch clients
		const snapshotClientes = await getDocs(collection(db, 'clientes'));
		clientes = snapshotClientes.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

		// Fetch configuraciones globales
		const docRef = doc(db, 'configuracion', 'global');
		const docSnap = await getDoc(docRef);

		if (docSnap.exists()) {
			const data = docSnap.data();
			configuraciones = data?.tiposServicio || [];
			markups = data?.tiposServicio || [];
			tipoCambioReceptivo = data?.cambioReceptivo || 950;
			tipoCambioContable = data?.cambioContable || 960;

			tiposDeServicio = [...new Set(configuraciones.map((c) => c.categoria))].filter(Boolean);
			serviciosPorTipo = configuraciones.reduce((acc, c) => {
				if (!c.categoria || !c.servicio) return acc;
				if (!acc[c.categoria]) acc[c.categoria] = [];
				if (!acc[c.categoria].includes(c.servicio)) acc[c.categoria].push(c.servicio);
				return acc;
			}, {});
		} else {
			console.warn('No se encontró el documento "global" en la colección "configuracion".');
		}
	});

	function handleClientSelect(id: string) {
		const cliente = clientes.find((c) => c.id === id);
		if (cliente) {
			clienteSeleccionado = id;
			email = cliente.correo1 || '';
			ejecutivo = cliente.ejecutivo1 || '';
			referenciaPasajero = cliente.referencia || '';
		}
	}

	async function handleSearch(filters: {
		destino: string;
		fechaInicio: string;
		fechaFin: string;
		tipoServicio: string;
		servicio: string;
		categoriaHotel: string;
		tourPrivado: string;
		duracionTour: string;
		filtroPrecioMin: number;
		filtroPrecioMax: number;
	}) {
		({
			destino,
			fechaInicio,
			fechaFin,
			tipoServicio,
			servicio,
			categoriaHotel,
			tourPrivado,
			duracionTour,
			filtroPrecioMin,
			filtroPrecioMax
		} = filters);
		await buscarServicios();
	}

	async function buscarServicios() {
		resultados = [];
		cargando = true;

		if (!destino || !tipoServicio || !servicio || !fechaInicio || !fechaFin) {
			cargando = false;
			return;
		}

		const snapshotProveedores = await getDocs(collection(db, 'proveedores'));
		const candidatosAjustados = [];
		const inicioBusqueda = new Date(fechaInicio);
		const finBusqueda = new Date(fechaFin);

		for (const proveedorDoc of snapshotProveedores.docs) {
			const serviciosRef = collection(db, `proveedores/${proveedorDoc.id}/servicios`);
			const serviciosSnap = await getDocs(serviciosRef);

			for (const docu of serviciosSnap.docs) {
				const data = docu.data();

				const ciudadServicio = (data.CIUDAD || '').toUpperCase();
				const destinoNormalizado = destino.toUpperCase();
				const tipoServicioUpper = (data['TIPO DE SERVICIO'] || '').toUpperCase();
				const servicioUpper = (data['SERVICIO/PRODUCTO/ F.I.T'] || '').toUpperCase();
				const servicioBuscado = servicio.toUpperCase();

				const inicioServicio = data['FECHA_INICIO']
					? new Date(data['FECHA_INICIO'].split('T')[0] )
					: null;
				const finServicio = data['FECHA_FIN']
					? new Date(data['FECHA_FIN'].split('T')[0] )
					: null;

				const coincideUbicacion = ciudadServicio === destinoNormalizado;
				const coincideTipo = tipoServicioUpper === tipoServicio.toUpperCase();
				const coincideServicio = servicioUpper === servicioBuscado;

				const viajeDentroDeServicio =
					inicioServicio &&
					finServicio &&
					inicioBusqueda >= inicioServicio && // El viaje comienza en o después del inicio del servicio
					finBusqueda <= finServicio;   

				if (coincideUbicacion && coincideTipo && coincideServicio && viajeDentroDeServicio) {
					const sobraAntes =
						(inicioBusqueda.getTime() - inicioServicio.getTime()) / (1000 * 60 * 60 * 24);
					const sobraDespues =
						(finServicio.getTime() - finBusqueda.getTime()) / (1000 * 60 * 60 * 24);
					const ajusteTotal = sobraAntes + sobraDespues;

					const markup = markups.find(
						(m) => m.categoria === tipoServicio && m.servicio === servicio
					)?.markup;
					const markupManual = markup ?? 0;

					const capacidad = parseInt(data['OCUPACION DE HAB O PAX']) || 0;

					if (tipoServicio.toUpperCase() === 'ALOJAMIENTO') {
						if (capacidad < 1) continue;
					} else if (tipoServicio.toUpperCase() === 'TRANSPORTE') {
						const rangoValido =
                        (cantidadPasajeros >= 1 && cantidadPasajeros <= 4 && capacidad >= 1 && capacidad <= 4) ||
                        (cantidadPasajeros >= 5 && cantidadPasajeros <= 7 && capacidad >= 5 && capacidad <= 7) ||
                        (cantidadPasajeros >= 8 && cantidadPasajeros <= 11 && capacidad >= 8 && capacidad <= 11) ||
                        (cantidadPasajeros >= 12 && cantidadPasajeros <= 19 && capacidad >= 12 && capacidad <= 19) ||
                        (cantidadPasajeros >= 20 && capacidad >= 20);
                    if (!rangoValido) continue;
					} else {
						if (capacidad !== cantidadPasajeros) continue;
					}

					let tarifaFinal = data['TARIFA NETA'];
					let moneda = data.MONEDA;

					if (markup) {
						let neta = data['TARIFA NETA'];
						let netaConvertida = neta;
						let porcentaje = markupManual;
						tarifaFinal = Math.round(netaConvertida / markup);

						if (tipoCliente === 'Extranjero' && moneda === 'PESO') {
							netaConvertida = neta / tipoCambioReceptivo;
							moneda = 'PESO';
						} else if (tipoCliente === 'Nacional' && moneda === 'DÓLAR') {
							netaConvertida = neta * tipoCambioContable;
							moneda = 'CLP';
						}

						tarifaFinal = Math.round(netaConvertida / porcentaje);

						if (tipoCliente === 'Nacional' && moneda === 'PESO') {
							tarifaFinal = Math.round(tarifaFinal * 1.19);
						}
					}
					if (
						categoriaHotel &&
						(data['CATEGORÍA HOTEL'] || '').toUpperCase() !== categoriaHotel.toUpperCase()
					)
						continue;

					if (tarifaFinal < filtroPrecioMin || tarifaFinal > filtroPrecioMax) continue;

					if (
						tourPrivado &&
						(data['TOUR PRIVADO REGULAR'] || '').toUpperCase() !== tourPrivado.toUpperCase()
					)
						continue;

					if (
						duracionTour &&
						(data['HALF DAY FULL DAY'] || '').toUpperCase() !== duracionTour.toUpperCase()
					)
						continue;

					candidatosAjustados.push({
						id: docu.id,
						proveedor: data.PROVEEDOR,
						descripcion: data.DESCRIPCIÓN,
						moneda,
						tarifa_neta: data['TARIFA NETA'],
						tarifaFinal: tarifaFinal,
						ciudad: data['CIUDAD'],
						pais: data['PAIS'],
						tipoServicio: data['TIPO DE SERVICIO'],
						servicioProducto: data['SERVICIO/PRODUCTO/ F.I.T'],
						nombreProducto: data['NOMBRE PRODUCTO SERVICIO'],
						tipoHabitacion: data['TIPO DE HABITACIÓN'],
						ocupacion: data['OCUPACION DE HAB O PAX'],
						porPaxoCapac: data['POR PAX O POR CAPAC'],
						categoria: data['CATEGORÍA HOTEL'],
						segmento: data['SEGMENTO CATEGORÍA HOTEL'],
						tourPrivado: data['TOUR PRIVADO REGULAR'],
						halfDay: data['HALF DAY FULL DAY'],
						temporada: data['TEMPORADA'],
						fechaIni: data['FECHA_INICIO'],
						fechaF: data['FECHA_FIN'],
						ajusteTotal: 0,
					});
				}
			}
		}

		if (candidatosAjustados.length > 0) {
			const minimoAjuste = Math.min(...candidatosAjustados.map((c) => c.ajusteTotal));
			resultados = candidatosAjustados.filter((c) => c.ajusteTotal === minimoAjuste);
		} else {
			resultados = [];
		}

		candidatosAjustados.sort((a, b) => {
			const capA = parseInt(a.ocupacion) || 0;
			const capB = parseInt(b.ocupacion) || 0;
			return capA - capB;
		});

		resultados = [...candidatosAjustados];
		cargando = false;
	}

	function handleServiceToggle(servicio: any) {
		const index = serviciosSeleccionados.findIndex((s) => s.id === servicio.id);
		if (servicio.tipoServicio.toUpperCase() === 'ALOJAMIENTO') {
			servicio.noches = 1;
		}

		if (index === -1) {
			serviciosSeleccionados = [
				...serviciosSeleccionados,
				{
					...servicio,
					noches: servicio.tipoServicio.toUpperCase() === 'ALOJAMIENTO' ? 1 : null,
					habitaciones: servicio.tipoServicio.toUpperCase() === 'ALOJAMIENTO' ? 1 : null,
					markupManual: 1 - obtenerMarkup(servicio.tipoServicio, servicio.servicioProducto) / 100
				}
			];
		} else {
			serviciosSeleccionados = serviciosSeleccionados.filter((_, i) => i !== index);
		}
	}

	function handleServiceRemove(indexToRemove: number) {
		serviciosSeleccionados = serviciosSeleccionados.filter((_, i) => i !== indexToRemove);
	}

	function handleMarkupChange(index: number, nuevoValor: number) {
		serviciosSeleccionados[index].markupManual = nuevoValor;
		serviciosSeleccionados = [...serviciosSeleccionados];
	}

	function totalCapacidadAlojamiento(servicios: any[]) {
		let total = 0;
		for (const s of servicios) {
			if (s.tipoServicio?.toUpperCase() === 'ALOJAMIENTO' && s.habitaciones && s.ocupacion) {
				total += parseInt(s.habitaciones) * parseInt(s.ocupacion);
			}
		}
		return total;
	}

	function calcularTarifaFinal(
		neta: number,
		markup: number,
		tipoCliente: string,
		moneda: string
	): number {
		let netaConvertida = neta;

		if (tipoCliente === 'Extranjero' && moneda === 'PESO') {
			netaConvertida = neta / tipoCambioReceptivo;
			moneda = 'DÓLAR';
		} else if (tipoCliente === 'Nacional' && moneda === 'DÓLAR') {
			netaConvertida = neta * tipoCambioContable;
			moneda = 'PESO';
		}

		let tarifaFinal = Math.round(netaConvertida / markup);

		if (tipoCliente === 'Nacional' && moneda === 'PESO') {
			tarifaFinal = Math.round(tarifaFinal * 1.19);
			moneda = 'CLP';
		}

		return tarifaFinal;
	}

	function obtenerMarkup(tipo: string, servicio: string): number {
		return markups.find((m) => m.categoria === tipo && m.servicio === servicio)?.markup ?? 0;
	}
</script>

<div class="mx-auto w-full p-6">
	<LoadingSpinner isVisible={cargando} />

	<h4 class="mb-6 text-4xl font-bold">Cotización</h4>
	<h1 class="mb-6 text-2xl font-bold">Datos Cliente</h1>
	<div class="mb-4 grid grid-cols-1 gap-4 text-sm sm:grid-cols-2 lg:grid-cols-5">
		<ClientSelector {clientes} bind:clienteSeleccionado onClientSelect={handleClientSelect} />
		<ClientDetails {ejecutivo} {email} {referenciaPasajero} />
		<select bind:value={tipoCliente} class="w-full rounded border px-2 py-1">
			<option>Extranjero</option>
			<option>Nacional</option>
		</select>
	</div>

	<hr class="my-4" />
	<h1 class="mb-6 text-2xl font-bold">Filtros de Busqueda</h1>
	<SearchFilters
		{destino}
		{fechaInicio}
		{fechaFin}
		{cantidadPasajeros}
		{tiposDeServicio}
		{tipoServicio}
		{serviciosPorTipo}
		{servicio}
		{categoriaHotel}
		{tourPrivado}
		{duracionTour}
		{filtroPrecioMin}
		{filtroPrecioMax}
		onSearch={handleSearch}
	/>

	<div class="mt-10">
		<SelectedServices
			serviciosSeleccionados={serviciosSeleccionados}
			{tipoCliente}
			{tipoCambioReceptivo}
			{tipoCambioContable}
			onServiceRemove={handleServiceRemove}
			onMarkupChange={handleMarkupChange}
			cantidadPasajeros={cantidadPasajeros}
		/>
		{#if totalCapacidadAlojamiento(serviciosSeleccionados) < cantidadPasajeros}
			<div class="mt-4 text-sm font-medium text-red-600">
				⚠️ La capacidad total de los alojamientos seleccionados ({totalCapacidadAlojamiento(serviciosSeleccionados)}) no cubre a {cantidadPasajeros} pasajeros.
			</div>
		{/if}
		<div class="mt-4 text-right font-semibold">
			Total Cotización:
			{serviciosSeleccionados
				.reduce((sum, s) => {
					let subtotal = 0;
					let precioBase = calcularTarifaFinal(s.tarifa_neta, 1, tipoCliente, s.moneda);
					// Usamos 1 como markup para obtener el precio base con conversión e IVA
		
					if (s.tipoServicio.toUpperCase() === 'ALOJAMIENTO') {
						const noches = s.noches ? parseInt(s.noches) : 1;
						const habs = s.habitaciones ? parseInt(s.habitaciones) : 1;
						subtotal = precioBase / s.markupManual * noches * habs;
						// Dividimos por s.markupManual para "inflar" el precio base con el margen
					} else {
						subtotal = precioBase / s.markupManual;
						// Dividimos por s.markupManual para "inflar" el precio base con el margen
					}
					return sum + subtotal;
				}, 0)
				.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
			{serviciosSeleccionados[0]?.moneda}
		</div>
	</div>

	<ServiceResults
		resultados={resultados}
		serviciosSeleccionados={serviciosSeleccionados}
		onServiceToggle={handleServiceToggle}
	/>
</div>

<style>
	 :global(body) {
		@apply bg-gray-100 text-gray-900;
	}

	table {
		width: 100%;
		background-color: white;
		color: black;
		border-collapse: collapse;
		margin-top: 1rem;
		border-radius: 0.5rem;
		overflow: hidden;
	}

	thead {
		background-color: #f3f4f6; /* gris clarito */
		position: sticky;
		top: 0;
		z-index: 1;
	}

	th,
	td {
		padding: 0.75rem 1rem;
		border-bottom: 1px solid #e5e7eb; /* Tailwind gray-200 */
	}

	tr:hover {
		background-color: #f9fafb; /* efecto hover clarito */
	}

	input[type='checkbox'] {
		transform: scale(1.2);
		accent-color: #3b82f6; /* azul Tailwind */
	}
	@keyframes spin {
		to {
			transform: rotate(360deg);
		}
	}
	.animate-spin {
		animation: spin 1s linear infinite;
	} 
</style>