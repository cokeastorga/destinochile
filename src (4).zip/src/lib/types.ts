export interface Cliente {
    id: string;
    nombre: string;
    correo1?: string;
    ejecutivo1?: string;
    referencia?: string;
  }
  