// lib/utils/cotizacion.ts

export function totalCapacidadAlojamiento(servicios: any[]): number {
    let total = 0;
    for (const s of servicios) {
      if (s.tipoServicio?.toUpperCase() === 'ALOJAMIENTO' && s.habitaciones && s.ocupacion) {
        total += parseInt(s.habitaciones) * parseInt(s.ocupacion);
      }
    }
    return total;
  }
  
  export function calcularTarifaFinal(
    neta: number,
    markup: number,
    tipoCliente: string,
    moneda: string,
    tipoCambioReceptivo: number,
    tipoCambioContable: number
  ): number {
    let netaConvertida = neta;
  
    if (tipoCliente === 'Extranjero' && moneda === 'PESO') {
      netaConvertida = neta / tipoCambioReceptivo;
      moneda = 'DÓLAR';
    } else if (tipoCliente === 'Nacional' && moneda === 'DÓLAR') {
      netaConvertida = neta * tipoCambioContable;
      moneda = 'PESO';
    }
  
    let tarifaFinal = Math.round(netaConvertida / markup);
  
    if (tipoCliente === 'Nacional' && moneda === 'PESO') {
      tarifaFinal = Math.round(tarifaFinal * 1.19);
      moneda = 'CLP';
    }
  
    return tarifaFinal;
  }
  