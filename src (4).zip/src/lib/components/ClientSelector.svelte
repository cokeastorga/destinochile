<script lang="ts">
	export let clientes: any[];
	export let clienteSeleccionado: string;
	export let onClientSelect: (id: string) => void;
</script>

<select
	bind:value={clienteSeleccionado}
	on:change={(e) => onClientSelect(e.target.value)}
	class="w-full rounded border px-2 py-1"
>
	<option value="">Seleccione cliente</option>
	{#each clientes as c}
		<option value={c.id}>{c.nombre}</option>
	{/each}
</select>