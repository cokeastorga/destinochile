<script lang="ts">
	export let ejecutivo: string;
	export let email: string;
	export let referenciaPasajero: string;
</script>

<input
	type="text"
	placeholder="Ejecutivo"
	bind:value={ejecutivo}
	class="w-full rounded border px-2 py-1"
	disabled
/>
<input
	type="email"
	placeholder="Correo electrónico"
	bind:value={email}
	class="w-full rounded border px-2 py-1"
	disabled
/>
<input
	type="text"
	placeholder="Referencia pasajero"
	bind:value={referenciaPasajero}
	class="w-full rounded border px-2 py-1"
/>