<script lang="ts">
	export let serviciosSeleccionados: any[];
	export let tipoCliente: string;
	export let tipoCambioReceptivo: number;
	export let tipoCambioContable: number;
	export let onServiceRemove: (index: number) => void;
	export let onMarkupChange: (index: number, nuevoValor: number) => void;

	function calcularTarifaFinal(
		neta: number,
		markup: number,
		tipoCliente: string,
		moneda: string
	): number {
		let netaConvertida = neta;

		if (tipoCliente === 'Extranjero' && moneda === 'PESO') {
			netaConvertida = neta / tipoCambioReceptivo;
			moneda = 'DÓLAR';
		} else if (tipoCliente === 'Nacional' && moneda === 'DÓLAR') {
			netaConvertida = neta * tipoCambioContable;
			moneda = 'PESO';
		}

		let tarifaFinal = Math.round(netaConvertida / markup);

		if (tipoCliente === 'Nacional' && moneda === 'PESO') {
			tarifaFinal = Math.round(tarifaFinal * 1.19);
			moneda = 'CLP';
		}

		return tarifaFinal;
	}
</script>

<h2 class="mb-4 text-lg font-semibold">Servicios Seleccionados</h2>

{#if serviciosSeleccionados.length > 0}
	<table class="w-full rounded border border-gray-300 bg-white text-sm text-gray-700 shadow">
		<thead class="bg-gray-100 text-xs uppercase">
			<tr>
				<th class="px-4 py-2">Tipo Servicio</th>
				<th class="px-4 py-2">Producto</th>
				<th class="px-4 py-2">Proveedor</th>
				<th class="px-4 py-2">Fecha Inicio</th>
				<th class="px-4 py-2">Fecha Fin</th>
				<th class="px-4 py-2">Noches</th>
				<th class="px-4 py-2">Habitaciones</th>
				<th class="px-4 py-2">Markup %</th>
				<th class="px-4 py-2">Subtotal</th>
				<th class="px-4 py-2">Acción</th>
			</tr>
		</thead>
		<tbody>
			{#each serviciosSeleccionados as s, index (s.nombreProducto + s.proveedor + index)}
				<tr class="border-t hover:bg-gray-50">
					<td class="px-4 py-2">{s.tipoServicio}</td>
					<td class="px-4 py-2">{s.nombreProducto}</td>
					<td class="px-4 py-2">{s.proveedor}</td>

					<td class="px-4 py-2">
						<input type="date" bind:value={s.fechaIni} class="rounded border px-2 py-1" />
					</td>
					<td class="px-4 py-2">
						<input type="date" bind:value={s.fechaF} class="rounded border px-2 py-1" />
					</td>

					{#if s.tipoServicio.toUpperCase() === 'ALOJAMIENTO'}
						<td class="px-4 py-2">
							<input
								type="number"
								min="1"
								bind:value={s.noches}
								class="w-16 rounded border px-2 py-1 text-center"
							/>
						</td>
						<td class="px-4 py-2">
							{#if s.ocupacion}
								<select bind:value={s.habitaciones} class="w-20 rounded border px-2 py-1">
									{#each Array.from({ length: Math.ceil(cantidadPasajeros / parseInt(s.ocupacion)) }, (_, i) => i + 1) as op}
										<option value={op}>{op}</option>
									{/each}
								</select>
							{:else}
								<span class="text-gray-400">No asignado</span>
							{/if}
						</td>
					{:else}
						<td class="px-4 py-2">—</td>
						<td class="px-4 py-2">—</td>
					{/if}
					<td class="px-4 py-2">
						<input
							type="number"
							min="0"
							max="1"
							step="0.01"
							bind:value={s.markupManual}
							class="w-20 rounded border px-2 py-1 text-center"
							on:change={(e) => onMarkupChange(index, parseFloat(e.target.value))}
						/>
					</td>

					<td class="px-4 py-2 font-semibold">
						{#if s.tipoServicio.toUpperCase() === 'ALOJAMIENTO'}
							{#if s.noches && s.habitaciones}
								{(
									calcularTarifaFinal(s.tarifa_neta, s.markupManual, tipoCliente, s.moneda) *
									s.noches *
									s.habitaciones
								).toLocaleString()}
								{s.moneda}
							{:else}
								0 {s.moneda}
							{/if}
						{:else}
							{calcularTarifaFinal(
								s.tarifa_neta,
								s.markupManual,
								tipoCliente,
								s.moneda
							).toLocaleString()}
							{s.moneda}
						{/if}
					</td>

					<td class="px-4 py-2 text-center">
						<button
							on:click={() => onServiceRemove(index)}
							class="font-bold text-red-600 hover:underline"
						>
							✕
						</button>
					</td>
				</tr>
			{/each}
		</tbody>
	</table>
{:else}
	<p class="mt-4 text-sm text-gray-500">No hay servicios seleccionados.</p>
{/if}