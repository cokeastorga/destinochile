<script lang="ts">
	export let resultados: any[];
	export let serviciosSeleccionados: any[];
	export let onServiceToggle: (servicio: any) => void;

	function isServicioSeleccionado(servicio: any): boolean {
		return serviciosSeleccionados.some((s) => s.id === servicio.id);
	}
</script>

{#if resultados.length > 0}
	<h2 class="mb-4 mt-8 text-xl font-bold">Resultados de Servicios Disponibles</h2>

	<table class="w-full border border-gray-300 text-left text-sm text-gray-700">
		<thead class="bg-gray-100 text-xs uppercase text-gray-700">
			<tr>
				<th class="px-4 py-2">Ciudad</th>
				<th class="px-4 py-2">Proveedor</th>
				<th class="px-4 py-2">Tipo de Servicio</th>
				<th class="px-4 py-2">Nombre Producto</th>
				<th class="px-4 py-2">Tipo de Habitación</th>
				<th class="px-4 py-2">Capacidad</th>
				<th class="px-4 py-2">Categoria</th>
				<th class="px-4 py-2">Segmento</th>
				<th class="px-4 py-2">Tour Privado o Regular</th>
				<th class="px-4 py-2">Half Day Full Day</th>
				<th class="px-4 py-2">Descripción</th>
				<th class="px-4 py-2">Temporada</th>
				<th class="px-4 py-2">Moneda</th>
				<th class="px-4 py-2">Tarifa Neta</th>
				<th class="px-4 py-2">Tarifa Final</th>
				<th class="px-4 py-2">FECHA INICIO</th>
				<th class="px-4 py-2">FECHA FIN</th>
				<th class="px-4 py-2">Seleccionar</th>
			</tr>
		</thead>
		<tbody>
			{#each resultados as servicio, index (servicio.nombre + servicio.proveedor + index)}
				<tr class="border-t">
					<td class="px-4 py-2">{servicio.ciudad}</td>
					<td class="px-4 py-2">{servicio.proveedor}</td>
					<td class="px-4 py-2">{servicio.tipoServicio}</td>
					<td class="px-4 py-2">{servicio.nombreProducto}</td>
					<td class="px-4 py-2">{servicio.tipoHabitacion}</td>
					<td class="px-4 py-2">{servicio.ocupacion}</td>
					<td class="px-4 py-2">{servicio.categoria}</td>
					<td class="px-4 py-2">{servicio.segmento}</td>
					<td class="px-4 py-2">{servicio.tourPrivado}</td>
					<td class="px-4 py-2">{servicio.halfDay}</td>
					<td class="px-4 py-2">{servicio.descripcion}</td>
					<td class="px-4 py-2">{servicio.temporada}</td>
					<td class="px-4 py-2">{servicio.moneda}</td>
					<td class="px-4 py-2">{servicio.tarifa_neta}</td>
					<td class="px-4 py-2">{servicio.tarifaFinal}</td>
					<td class="px-4 py-2">{servicio.fechaIni}</td>
					<td class="px-4 py-2">{servicio.fechaF}</td>
					<td class="px-4 py-2 text-center">
						<input
							type="checkbox"
							checked={isServicioSeleccionado(servicio)}
							on:change={() => onServiceToggle(servicio)}
							class="cursor-pointer"
						/>
					</td>
				</tr>
			{/each}
		</tbody>
	</table>
{:else}
	<div class="mt-8 rounded border border-gray-300 bg-white p-6 text-center text-gray-600 shadow">
		<p class="mb-2 text-lg font-semibold">No se encontraron servicios que coincidan.</p>
		<p class="text-sm">
			Prueba ajustando los filtros como fechas, cantidad de pasajeros, categoría de hotel o rango
			de precio.
		</p>
	</div>
{/if}